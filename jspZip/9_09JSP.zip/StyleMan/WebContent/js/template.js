$(document).ready(function() {

	// 수량이 변경됐을 때 실행...
	$(document).on('click', '#joinBtn', function() {
		location.href = '?pageChange=join.jsp';

	});
});