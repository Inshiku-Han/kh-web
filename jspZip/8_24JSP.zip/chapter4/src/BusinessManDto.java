
public class BusinessManDto {
private	String name;
private String age;
private	String level;
private	String year;
private String admin;
public BusinessManDto() {
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public String getLevel() {
	return level;
}
public void setLevel(String level) {
	this.level = level;
}
public String getYear() {
	return year;
}
public void setYear(String year) {
	this.year = year;
}
public String getAdmin() {
	return admin;
}
public void setAdmin(String admin) {
	this.admin = admin;
}

}
